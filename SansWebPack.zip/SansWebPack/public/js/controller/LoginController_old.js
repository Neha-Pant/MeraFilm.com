module.exports = function($scope, $http,$rootScope,$location)
{
  $scope.login=function()
  {
    var n=document.getElementById("name").value;
    var p=document.getElementById("pass").value;

    $http.get('/conapi/logincheck/'+n+'/'+p).success(function (response) {
      $scope.usersData=response;
    if($scope.usersData.length<1)
    alert('ERROR : No user found .');
    else {
      $location.path("/mapping");
    }
    });
  };

  $scope.signup=function()
  {
    var n=document.getElementById("name").value;
    var p=document.getElementById("pass").value;
    var p1=document.getElementById("pass1").value;

    if(p!=p1)
    {
      alert('ERROR :  Password and confirm password does not match .');
    }
    else {
    $http.post('/conapi/signup/'+n+'/'+p).success(function (response) {
    });
    alert('Registered successfully .');
    $location.path("/");
  }
    }
  };
